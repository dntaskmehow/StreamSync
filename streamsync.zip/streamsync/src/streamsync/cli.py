import argparse
import sys
from .config import RaceConfig
from .h2_engine import H2RaceEngine
from .analyzer import ResponseAnalyzer

def main():
    parser = argparse.ArgumentParser(description="StreamSync: HTTP/2 Single-Packet Race Condition Fuzzer.")
    parser.add_argument("--url", required=True, help="Target HTTPS URL.")
    parser.add_argument("--method", default="GET", help="HTTP method (default: GET).")
    parser.add_argument("--data", default=None, help="HTTP request body data.")
    parser.add_argument("--concurrency", type=int, default=20, help="Number of multiplexed streams in single burst.")
    parser.add_argument("--header", action="append", default=[], help="Custom header in format 'Key: Value'.")

    args = parser.parse_args()

    headers = {}
    for h in args.header:
        if ":" in h:
            k, v = h.split(":", 1)
            headers[k.strip()] = v.strip()

    config = RaceConfig(
        url=args.url,
        method=args.method.upper(),
        headers=headers,
        body=args.data,
        concurrency=args.concurrency
    )

    try:
        print(f"[*] Dispatching HTTP/2 single-packet burst of {config.concurrency} streams to {config.url}...")
        engine = H2RaceEngine(config)
        results = engine.execute_burst()
        ResponseAnalyzer.evaluate_burst(results)
    except Exception as e:
        print(f"[!] Execution Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()

from typing import List
from rich.console import Console
from rich.table import Table
from .h2_engine import ResponseResult

console = Console()

class ResponseAnalyzer:
    @staticmethod
    def evaluate_burst(results: List[ResponseResult]):
        table = Table(title="[bold cyan]StreamSync Single-Packet Race Burst Results[/bold cyan]")
        table.add_column("Stream ID", style="magenta", no_wrap=True)
        table.add_column("HTTP Status", style="bold green")
        table.add_column("Content Length", style="yellow")
        table.add_column("Response Preview", style="white")

        status_counts = {}
        for r in results:
            status = r.status
            status_counts[status] = status_counts.get(status, 0) + 1
            preview = r.body[:60].decode('utf-8', errors='ignore').replace('\n', ' ')
            table.add_row(
                str(r.stream_id),
                str(status),
                str(len(r.body)),
                preview
            )

        console.print(table)

        if len(status_counts) > 1:
            console.print("[bold red][!] ANOMALY DETECTED: Multiple distinct status codes across multiplexed streams. Potential Race Condition / TOCTOU vulnerability![/bold red]")
        else:
            console.print("[green]? Uniform response codes across all streams. Endpoint handled concurrent single-packet burst cleanly.[/green]")

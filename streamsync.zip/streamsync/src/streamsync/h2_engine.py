import ssl
import socket
from urllib.parse import urlparse
from typing import List, Dict, Any
from h2.connection import H2Connection
from h2.config import H2Configuration
from .config import RaceConfig

class ResponseResult:
    def __init__(self, stream_id: int, status: int, headers: Dict[str, str], body: bytes):
        self.stream_id = stream_id
        self.status = status
        self.headers = headers
        self.body = body

class H2RaceEngine:
    def __init__(self, config: RaceConfig):
        self.config = config
        self.parsed_url = urlparse(config.url)
        self.host = self.parsed_url.hostname
        self.port = self.parsed_url.port or (443 if self.parsed_url.scheme == "https" else 80)
        self.path = self.parsed_url.path or "/"
        if self.parsed_url.query:
            self.path += f"?{self.parsed_url.query}"

    def execute_burst(self) -> List[ResponseResult]:
        if self.parsed_url.scheme != "https":
            raise ValueError("StreamSync requires HTTPS / HTTP/2 over TLS with ALPN.")

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        if hasattr(ctx, 'set_alpn_protocols'):
            ctx.set_alpn_protocols(['h2'])

        sock = socket.create_connection((self.host, self.port), timeout=self.config.timeout)
        conn_sock = ctx.wrap_socket(sock, server_hostname=self.host)

        alpn = conn_sock.selected_alpn_protocol()
        if alpn != 'h2':
            conn_sock.close()
            raise RuntimeError(f"Target does not support HTTP/2 (ALPN negotiated: {alpn})")

        c_config = H2Configuration(client_side=True)
        client = H2Connection(config=c_config)
        client.initiate_connection()
        conn_sock.sendall(client.data_to_send())

        results: Dict[int, Dict[str, Any]] = {}
        stream_ids = []

        headers = [
            (':method', self.config.method),
            (':path', self.path),
            (':authority', self.host),
            (':scheme', 'https'),
            ('user-agent', 'StreamSync/1.0 (Professor-Bug-R&D)')
        ]
        for k, v in self.config.headers.items():
            headers.append((k.lower(), v))

        if self.config.body:
            headers.append(('content-length', str(len(self.config.body))))

        for i in range(self.config.concurrency):
            stream_id = client.get_next_available_stream_id()
            stream_ids.append(stream_id)
            results[stream_id] = {"status": None, "headers": {}, "body": bytearray()}
            
            end_stream = not bool(self.config.body)
            client.send_headers(stream_id, headers, end_stream=end_stream)

            if self.config.body:
                client.send_data(stream_id, self.config.body.encode('utf-8'), end_stream=True)

        conn_sock.sendall(client.data_to_send())

        conn_sock.settimeout(self.config.timeout)
        try:
            while len(stream_ids) > 0:
                data = conn_sock.recv(65535)
                if not data:
                    break
                events = client.receive_data(data)
                for event in events:
                    if hasattr(event, 'stream_id') and event.stream_id in results:
                        s_id = event.stream_id
                        if event.__class__.__name__ == 'ResponseReceived':
                            for hk, hv in event.headers:
                                if hk == b':status':
                                    results[s_id]['status'] = int(hv.decode('utf-8'))
                                else:
                                    results[s_id]['headers'][hk.decode('utf-8')] = hv.decode('utf-8')
                        elif event.__class__.__name__ == 'DataReceived':
                            results[s_id]['body'].extend(event.data)
                        elif event.__class__.__name__ == 'StreamEnded':
                            if s_id in stream_ids:
                                stream_ids.remove(s_id)

                out_data = client.data_to_send()
                if out_data:
                    conn_sock.sendall(out_data)
        except socket.timeout:
            pass
        finally:
            client.close_connection()
            conn_sock.close()

        final_responses = []
        for s_id in sorted(results.keys()):
            r = results[s_id]
            final_responses.append(ResponseResult(
                stream_id=s_id,
                status=r['status'] or 0,
                headers=r['headers'],
                body=bytes(r['body'])
            ))

        return final_responses

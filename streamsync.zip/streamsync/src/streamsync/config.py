from typing import Dict, Optional
from pydantic import BaseModel, Field

class RaceConfig(BaseModel):
    url: str
    method: str = "GET"
    headers: Dict[str, str] = Field(default_factory=dict)
    body: Optional[str] = None
    concurrency: int = 20
    timeout: float = 5.0

import unittest
from streamsync.config import RaceConfig
from streamsync.h2_engine import H2RaceEngine

class TestStreamSync(unittest.TestCase):
    def test_config_initialization(self):
        config = RaceConfig(url="https://example.com/api/v1/redeem", concurrency=10)
        self.assertEqual(config.concurrency, 10)
        self.assertEqual(config.url, "https://example.com/api/v1/redeem")

    def test_engine_setup(self):
        config = RaceConfig(url="https://example.com/test")
        engine = H2RaceEngine(config)
        self.assertEqual(engine.host, "example.com")
        self.assertEqual(engine.path, "/test")

if __name__ == "__main__":
    main()
